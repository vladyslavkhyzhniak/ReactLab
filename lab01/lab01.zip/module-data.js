export const people = [
    {
        "id": 1,
        "name": "B",
        "birthDate": "1984-01-02",
        "email": "b1@wsei.edu.pl",
        "phone": "926-944-112"
    },
    {
        "id": 2,
        "name": "B",
        "birthDate": "1985-11-15",
        "email": "b2@wsei.edu.pl",
        "phone": "842-891-662"
    },
    {
        "id": 3,
        "name": "B",
        "birthDate": "1982-02-24",
        "email": "b3@wsei.edu.pl",
        "phone": "378-937-986"
    },
    {
        "id": 4,
        "name": "E",
        "birthDate": "1996-02-25",
        "email": "e1@wsei.edu.pl",
        "phone": "700-783-766"
    },
    {
        "id": 5,
        "name": "E",
        "birthDate": "1982-03-05",
        "email": "e2@wsei.edu.pl",
        "phone": "662-661-105"
    },
    {
        "id": 6,
        "name": "F",
        "birthDate": "1995-03-21",
        "email": "f1@wsei.edu.pl",
        "phone": "396-156-419"
    },
    {
        "id": 7,
        "name": "D",
        "birthDate": "1986-03-19",
        "email": "d1@wsei.edu.pl",
        "phone": "772-126-919"
    },
    {
        "id": 8,
        "name": "E",
        "birthDate": "2004-10-21",
        "email": "e3@wsei.edu.pl",
        "phone": "676-383-859"
    },
    {
        "id": 9,
        "name": "A",
        "birthDate": "1984-02-22",
        "email": "a1@wsei.edu.pl",
        "phone": "326-757-567"
    },
    {
        "id": 10,
        "name": "D",
        "birthDate": "2005-06-13",
        "email": "d2@wsei.edu.pl",
        "phone": "413-216-675"
    }
];
